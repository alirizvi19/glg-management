<?php include 'inc/header.php';?>

<!-- ! Main ! -->


<h1>TEXT</h1>

<h2>TEXT</h2>

<h3>TEXT</h3>


<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas quos, repellendus, similique, rem quidem asperiores voluptatem eveniet doloribus non expedita excepturi voluptas iusto sapiente? Optio.
</p>

<a class="btn"> text </a>
<!-- ! Main ! -->

<?php include 'inc/footer.php';?>